import { useParams } from "react-router-dom";
import { useState, useEffect } from "react";
import matter from "gray-matter";
import { marked } from "marked";

export default function BlogPost() {
  const { slug } = useParams();
  const [content, setContent] = useState<any>(null);

  useEffect(() => {
    import(`../posts/${slug}.md?raw`)
      .then((module) => {
        const { data, content } = matter(module.default);
        const html = marked(content);
        setContent({ ...data, html });
      })
      .catch((err) => console.error("Erro ao carregar post:", err));
  }, [slug]);

  if (!content) return <p className="p-6 text-gray-500">Carregando...</p>;

  return (
    <article className="max-w-4xl mx-auto px-4 py-8 bg-white shadow-md rounded-2xl">
      <header className="mb-8 border-b pb-4">
        <h1 className="text-3xl font-bold text-gray-900">{content.title}</h1>
        <p className="text-sm text-gray-500 mt-1">{content.date}</p>
      </header>

      <div className="prose prose-lg max-w-none mt-6 text-gray-800 leading-relaxed">
        <div dangerouslySetInnerHTML={{ __html: content.html }} />
      </div>
    </article>
  );
}
