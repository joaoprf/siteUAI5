import { Helmet } from "react-helmet";

interface SeoProps {
  title?: string;
  description?: string;
  keywords?: string[];
  image?: string;
  url?: string;
}

export default function Seo({
  title = "Uai5 | Desenvolvimento de Software e Chatbots Inteligentes",
  description = "A Uai5 desenvolve soluções em software, automação e chatbots com inteligência artificial para empresas que buscam inovação e eficiência.",
  keywords = [
    "chatbot whatsapp",
    "desenvolvimento de software",
    "inteligência artificial",
    "automação de atendimento",
    "Uai5"
  ],
  image = "https://uaifive.com/images/og-image.jpg",
  url = "https://uaifive.com",
}: SeoProps) {
  return (
    <Helmet>
      <title>{title}</title>
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords.join(", ")} />
      <meta property="og:type" content="website" />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={image} />
      <meta property="og:url" content={url} />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={image} />
      <link rel="canonical" href={url} />
    </Helmet>
  );
}
